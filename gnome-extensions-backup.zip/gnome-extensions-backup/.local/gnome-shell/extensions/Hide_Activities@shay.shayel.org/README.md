# Hide Activities Button

A simple GNOME Shell extenstion to hide the Activities button from the
status bar.

## Installation instructions

1. Move the Hide_Activities@shay.shayel.org directory into
   ~/.local/share/gnome-shell/extenstions/
2. Press Alt+F2, and in the window that opens, type 'r' and enter to
   restart GNOME shell.
3. Enable the extension by using gnome-tweak-tool.
